package tests.contactuspage;

public class TestContactUsPage {
}
