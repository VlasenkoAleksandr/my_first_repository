package tests;


import deflogger.TestsLogger;
import listeners.CustomListener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import pageobjects.signup.SignUpPage;
import steps.MainPageSteps;

@Listeners(CustomListener.class)
public class BaseTest {
    String testingPage = "http://automationpractice.com/index.php";

    protected MainPageSteps mainPageSteps;
    private WebDriver driver;

    @BeforeMethod()
    public void prepareEnv(){
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        System.setProperty("webdriver.gecko.driver","D:\\seleniumid\\src\\main\\resources\\geckodriver.exe");

        desiredCapabilities.setCapability("marionette",true);
        driver = new FirefoxDriver();
        driver.get(testingPage);

        mainPageSteps = new MainPageSteps(driver);

    }

    @AfterMethod()
    public void cleanUpEnv(){
        driver.quit();
    }

}
