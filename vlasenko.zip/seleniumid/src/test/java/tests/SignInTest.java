package tests;

import listeners.CustomListener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import steps.signup.SignUpPageSteps;

@Listeners(CustomListener.class)
public class SignInTest {
    String testingpage = "http://automationpractice.com/index.php?controller=authentication";

    protected SignUpPageSteps signUpPageSteps;
    private WebDriver driver;

    @BeforeMethod()
    public void prepareEnv(){
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
        System.setProperty("webdriver.gecko.driver","D:\\seleniumid\\src\\main\\resources\\geckodriver.exe");

        desiredCapabilities.setCapability("marionette",true);
        driver = new FirefoxDriver();
        driver.get(testingpage);

        signUpPageSteps = new SignUpPageSteps(driver);
    }

    @AfterMethod()
    public void cleanUpEnv(){
        driver.quit();
    }
}
