package tests.mainpage;

import deflogger.TestsLogger;
import org.testng.annotations.Test;
import steps.signup.SignUpPageSteps;
import steps.sitemap.SiteMapPageSteps;
import tests.BaseTest;

import static org.testng.Assert.assertEquals;
import static testingutils.Constants.UserDataLimitations.maxPasswordLength;

public class TestMainPage extends BaseTest {

    @Test(description = "41")
    public void testMyOrdersButtonForNotSignInMember(){
        TestsLogger.logMethodName();
        SignUpPageSteps signUpPageSteps = mainPageSteps.clickMyOrdersButton();
        boolean result = signUpPageSteps.isAuthenticationNavigatorDisplayed();

        assertEquals(result, true);
    }

    @Test(description = "43")
    public void testMyOrdersButtonForSignInMember(){

    }

    @Test(description = "44")
    public void testMyPersonalInfoForNotSignInMember(){
        TestsLogger.logMethodName();
        SignUpPageSteps signUpPageSteps = mainPageSteps.clickMyPersonalInfoButton();
        boolean result = signUpPageSteps.isAuthenticationNavigatorDisplayed();

        assertEquals(result, true);
    }

    @Test(description = "45")
    public void testMyPersonalInfoForSignInMember(){

    }

    @Test(description = "46")
    public void testSiteMapButton(){
        TestsLogger.logMethodName();
        SiteMapPageSteps siteMapPageSteps = mainPageSteps.clickSiteMapButton();
        boolean result = siteMapPageSteps.isSiteMapNavigatorDisplayed();
//        int var = maxPasswordLength;

        assertEquals(result,true);

    }
}
