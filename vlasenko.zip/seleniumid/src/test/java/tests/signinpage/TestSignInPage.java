package tests.signinpage;

import deflogger.TestsLogger;
import org.testng.annotations.Test;
import steps.forgotyourpassword.ForgotYourPasswordPageSteps;
import steps.signup.SignUpPageSteps;
import tests.BaseTest;

public class TestSignInPage extends BaseTest {

    @Test(description = "57")
    public void testForgotYourPasswordButton(){
        TestsLogger.logMethodName();
        SignUpPageSteps signUpPageSteps = mainPageSteps.clickSignInButton();
        ForgotYourPasswordPageSteps forgotYourPasswordPageSteps =  signUpPageSteps.clickForgotYourPasswordButton();
    }

}
