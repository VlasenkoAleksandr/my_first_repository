package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pageobjects.MainPage;
import steps.contactus.ContactUsPageSteps;
import steps.signup.SignUpPageSteps;
import steps.sitemap.SiteMapPageSteps;

public class MainPageSteps {

    private MainPage mainPage;
    protected WebDriver driver;

    public MainPageSteps(WebDriver driver) {
        this.driver = driver;
        mainPage = PageFactory.initElements(driver, MainPage.class);
    }

    public void submitSearch() {
        mainPage.getSubmitSearchButton().click();
    }

    public void enterTextInSearch(String searchText){
        mainPage.getSearchquery().sendKeys(searchText);

    }

    public SiteMapPageSteps clickSiteMapButton(){
        mainPage.getSiteMapButton().click();
        return new SiteMapPageSteps(driver);
    }

    public SignUpPageSteps clickSignInButton(){
        mainPage.getSignInButton().click();
        return new SignUpPageSteps(driver);
    }

    public ContactUsPageSteps clickContactUsButton(){
        mainPage.getContactUsButton().click();
        return new ContactUsPageSteps(driver);
    }

    public SignUpPageSteps clickMyPersonalInfoButton(){
        mainPage.getMypersonalinfoLink().click();
        return new SignUpPageSteps(driver);
    }

    public SignUpPageSteps clickMyOrdersButton(){
        mainPage.getMyOrdersButton().click();
        return new SignUpPageSteps(driver);
    }

}
