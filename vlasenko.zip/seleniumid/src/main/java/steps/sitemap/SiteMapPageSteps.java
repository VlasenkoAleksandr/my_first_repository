package steps.sitemap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pageobjects.sitemap.SiteMapPage;
import steps.MainPageSteps;

public class SiteMapPageSteps extends MainPageSteps{

    private SiteMapPage siteMapPage;

    public SiteMapPageSteps(WebDriver driver) {
        super(driver);
        siteMapPage = PageFactory.initElements(driver, SiteMapPage.class);
    }

    public boolean isSiteMapNavigatorDisplayed(){
        return siteMapPage.getSiteMapElement().isDisplayed();

    }

}
