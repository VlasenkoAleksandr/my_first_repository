package steps.forgotyourpassword;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pageobjects.forgotyourpassword.ForgotYourPasswordPage;
import steps.MainPageSteps;

public class ForgotYourPasswordPageSteps extends MainPageSteps{

    private ForgotYourPasswordPage forgotYourPasswordPage;

    public ForgotYourPasswordPageSteps(WebDriver driver){
        super(driver);
        forgotYourPasswordPage = PageFactory.initElements(driver,ForgotYourPasswordPage.class);
    }

    public boolean isRetrievePasswordButtonDisplayed(){
        return forgotYourPasswordPage.getRetrievePasswordButton().isDisplayed();

    }
}
