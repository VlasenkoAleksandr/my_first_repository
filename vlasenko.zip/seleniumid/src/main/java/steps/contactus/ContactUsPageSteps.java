package steps.contactus;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pageobjects.contactus.ContactUsPage;
import steps.MainPageSteps;

public class ContactUsPageSteps extends MainPageSteps{

    private ContactUsPage contactUsPage;

    public ContactUsPageSteps(WebDriver driver){
        super(driver);
        contactUsPage = PageFactory.initElements(driver,ContactUsPage.class);
    }

}
