package steps.login;

import org.openqa.selenium.WebDriver;
import steps.MainPageSteps;

public class LoginPageSteps extends MainPageSteps{

    public LoginPageSteps(WebDriver driver) {
        super(driver);
    }
}
