package steps.signup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pageobjects.forgotyourpassword.ForgotYourPasswordPage;
import pageobjects.signup.SignUpPage;
import steps.MainPageSteps;
import steps.forgotyourpassword.ForgotYourPasswordPageSteps;

public class SignUpPageSteps extends MainPageSteps{
    private SignUpPage signUpPage;

    public SignUpPageSteps(WebDriver driver) {
        super(driver);
        signUpPage = PageFactory.initElements(driver, SignUpPage.class);
    }

    public boolean isAuthenticationNavigatorDisplayed(){
        return signUpPage.getAuthenticationNavigator().isDisplayed();
    }

    public ForgotYourPasswordPageSteps clickForgotYourPasswordButton(){
        signUpPage.getForgtoyourpasswordLink().click();
        return new ForgotYourPasswordPageSteps(driver);
    }
}
