package pageobjects.login;

import pageobjects.MainPage;

public class LoginPage extends MainPage{
}
