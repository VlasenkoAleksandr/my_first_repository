package pageobjects.sitemap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageobjects.MainPage;

public class SiteMapPage extends MainPage{

    @FindBy(className = "navigation_page")
    private WebElement siteMapNavigator;

    public WebElement getSiteMapElement() {
        return siteMapNavigator;
    }
}
