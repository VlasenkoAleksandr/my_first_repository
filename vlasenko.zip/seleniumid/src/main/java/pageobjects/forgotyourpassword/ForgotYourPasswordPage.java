package pageobjects.forgotyourpassword;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageobjects.MainPage;

public class ForgotYourPasswordPage extends MainPage {

    @FindBy(css = "//*[@id=\"form_forgotpassword\"]/fieldset/p/button")
    private WebElement retrievePasswordButton;

    public WebElement getRetrievePasswordButton() {
        return retrievePasswordButton;
    }
}
