package pageobjects.contactus;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageobjects.MainPage;

public class ContactUsPage extends MainPage {

    @FindBy(id="id_contact")
    private WebElement subjectHeadingList;

    @FindBy(id="email")
    private WebElement emailAtContactUsPageTextField;

    @FindBy(id="message")
    private WebElement messageTextArea;

    @FindBy(className ="action")
    private WebElement chooseFileButton;

    public WebElement getSubjectHeadingList() {
        return subjectHeadingList;
    }

    public WebElement getEmailAtContactUsPageTextField() {
        return emailAtContactUsPageTextField;
    }

    public WebElement getMessageTextArea() {
        return messageTextArea;
    }

    public WebElement getChooseFileButton() {
        return chooseFileButton;
    }
}
