package pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MainPage {

    @FindBy(name = "submit_search")
    private WebElement submitSearchButton;

    @FindBy(id = "contact-link")
    private WebElement contactUsButton;

    @FindBy(className = "login")
    private WebElement signInButton;

    @FindBy(css = "img[src$='sale70.png']")
    private WebElement getSavingsNowButton;

    @FindBy(xpath = "//*[text()='0123-456-789']")
    private WebElement phoneNumber;

    @FindBy(className = "logo img-responsive")
    private WebElement logoButton;

    @FindBy(id="search_query_top")
    private WebElement searchquery;

    @FindBy(className = "shopping_cart")
    private WebElement cart;

    @FindBy(xpath = "//*[@id=\"block_top_menu\"]/ul/li[1]/a")
    private WebElement womenButton;

    @FindBy(xpath = "//*[@id=\"block_top_menu\"]/ul/li[2]/a")
    private WebElement dressesButton;

    @FindBy(xpath = "//*[@id=\"block_top_menu\"]/ul/li[3]/a")
    private WebElement tShirtsButton;

    @FindBy(className = "homefeatured")
    private WebElement popularButton;

    @FindBy(className = "blockbestsellers")
    private WebElement bestSellersButton;

    @FindBy(css = "[title=\"Sitemap\"]")
    private WebElement siteMapButton;

    @FindBy(css = "[title=\"My orders\"]")
    private WebElement myOrdersButton;

    @FindBy(linkText ="My personal info")
    private WebElement mypersonalinfoLink;

    public WebElement getMypersonalinfoLink() {
        return mypersonalinfoLink;
    }

    public WebElement getMyOrdersButton() {
        return myOrdersButton;
    }

    public WebElement getSiteMapButton() {
        return siteMapButton;
    }

    public WebElement getSubmitSearchButton() {
        return submitSearchButton;
    }

    public WebElement getContactUsButton() {
        return contactUsButton;
    }

    public WebElement getSignInButton() {
        return signInButton;
    }

    public WebElement getGetSavingsNowButton() {
        return getSavingsNowButton;
    }

    public WebElement getPhoneNumber() {
        return phoneNumber;
    }

    public WebElement getLogoButton() {
        return logoButton;
    }

    public WebElement getSearchquery() {
        return searchquery;
    }

    public WebElement getCart() {
        return cart;
    }

    public WebElement getWomenButton() {
        return womenButton;
    }

    public WebElement getDressesButton() {
        return dressesButton;
    }

    public WebElement gettShirtsButton() {
        return tShirtsButton;
    }

    public WebElement getPopularButton() {
        return popularButton;
    }

    public WebElement getBestSellersButton() {
        return bestSellersButton;
    }
}
