package pageobjects.signup;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageobjects.MainPage;

public class SignUpPage extends MainPage {

    @FindBy(className = "navigation_page")
    private WebElement authenticationNavigator;

    @FindBy(name="email_create")
    private WebElement emailcreatetextfield;

    @FindBy(id="SubmitCreate")
    private WebElement submitCreateButton;

    @FindBy(id="customer_firstname")
    private WebElement customerFristNameTextField;

    @FindBy(id="customer_lastname")
    private WebElement customerLastNameTextField;

    @FindBy(id="passwd")
    private WebElement passwordAtRegistrationPage;

    @FindBy(id="address1")
    private WebElement customerAddressTextField;

    @FindBy(id="city")
    private WebElement customerCityTextField;

    @FindBy(id="id_state")
    private WebElement customerStateList;

    @FindBy(id="postcode")
    private WebElement customerPostCodeTextField;

    @FindBy(id="id_country")
    private WebElement customerCountryList;

    @FindBy(id="phone_mobile")
    private WebElement customerMobilePhoneTextField;

    @FindBy(id="submitAccount")
    private WebElement submitAccountCreationButton;

    @FindBy(id="email")
    private WebElement emailAlreadyRegisteredCustomerTextField;

    @FindBy(id="passwd")
    private WebElement passwordAlreadyRegisteredCustomerTextField;

    @FindBy(id="SubmitLogin")
    private WebElement signInButtonAtSignInPage;

    @FindBy(linkText = "Forgot your password?")
    private WebElement forgtoyourpasswordLink;

    public WebElement getEmailAlreadyRegisteredCustomerTextField() {
        return emailAlreadyRegisteredCustomerTextField;
    }

    public WebElement getPasswordAlreadyRegisteredCustomerTextField() {
        return passwordAlreadyRegisteredCustomerTextField;
    }

    public WebElement getSignInButtonAtSignInPage() {
        return signInButtonAtSignInPage;
    }

    public WebElement getForgtoyourpasswordLink() {
        return forgtoyourpasswordLink;
    }

    public WebElement getCustomerLastNameTextField() {
        return customerLastNameTextField;
    }

    public WebElement getPasswordAtRegistrationPage() {
        return passwordAtRegistrationPage;
    }

    public WebElement getCustomerAddressTextField() {
        return customerAddressTextField;
    }

    public WebElement getCustomerCityTextField() {
        return customerCityTextField;
    }

    public WebElement getCustomerStateList() {
        return customerStateList;
    }

    public WebElement getCustomerPostCodeTextField() {
        return customerPostCodeTextField;
    }

    public WebElement getCustomerCountryList() {
        return customerCountryList;
    }

    public WebElement getCustomerMobilePhoneTextField() {
        return customerMobilePhoneTextField;
    }

    public WebElement getSubmitAccountCreationButton() {
        return submitAccountCreationButton;
    }

    public WebElement getCustomerFristNameTextField() {
        return customerFristNameTextField;
    }

    public WebElement getSubmitCreateButton() {
        return submitCreateButton;
    }

    public WebElement getEmailcreatetextfield() {
        return emailcreatetextfield;
    }

    public WebElement getAuthenticationNavigator() {
        return authenticationNavigator;
    }
}
