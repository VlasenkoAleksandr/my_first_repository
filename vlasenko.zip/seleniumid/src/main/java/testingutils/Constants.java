package testingutils;

public class Constants {

    private Constants(){


    }

    public static final class UserDataLimitations{
        private UserDataLimitations(){ }

        public static final int maxPasswordLength = 255;
    }

    public static final class SiteMapLimitations{

    }
}
